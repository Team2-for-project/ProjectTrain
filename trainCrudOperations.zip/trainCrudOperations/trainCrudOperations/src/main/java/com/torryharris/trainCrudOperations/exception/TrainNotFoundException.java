package com.torryharris.trainCrudOperations.exception;

import com.torryharris.trainCrudOperations.model.Train;

public class TrainNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    public TrainNotFoundException() {
        super();
    }

    public TrainNotFoundException(String customMessage) {
        super(customMessage);
    }
}
