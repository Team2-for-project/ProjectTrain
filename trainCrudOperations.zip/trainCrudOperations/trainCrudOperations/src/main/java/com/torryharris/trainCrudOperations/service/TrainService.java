package com.torryharris.trainCrudOperations.service;

import com.torryharris.trainCrudOperations.model.Train;

import java.util.List;

public interface TrainService {
    public Train saveTrain(Train train);
    public List<Train> getAllTrains();
    public Train getTrainByTrainNo(int trainNO);
    public void deleteTrainByTrainNo(int trainNO);
    public void updateTrain(Train train);
}
