package com.torryharris.trainCrudOperations.controller;

import com.torryharris.trainCrudOperations.exception.TrainNotFoundException;
import com.torryharris.trainCrudOperations.model.Train;
import com.torryharris.trainCrudOperations.service.TrainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/train")
public class TrainController {
    @Autowired
    private TrainService service;

    @GetMapping(value="/")
    public String showHomePage() {
        return "homePage";
    }

    @GetMapping("/register")
    public String showRegistration() {
        return "registerTrainPage";
    }
    @PostMapping("/save")
    public String saveInvoice(
            @ModelAttribute Train train,
            Model model
    ) {
        service.saveTrain(train);
        int trainNo = service.saveTrain(train).getTrainNo();
        String message = "Record with Train Number : '"+trainNo+"' is saved successfully !";
        model.addAttribute("message", message);
        return "registerTrainPage";
    }
    @GetMapping("/getAllTrains")
    public String getAllTrains(@RequestParam(value = "message", required = false) String message,
            Model model ) {
        List<Train> trains= service.getAllTrains();
        model.addAttribute("list", trains);
        model.addAttribute("message", message);
        return "allTrainsPage";
    }
    @GetMapping("/edit")
    public String getEditPage(
            Model model,
            RedirectAttributes attributes,
            @RequestParam int trainNo
    ) {
        String page = null;
        try {
            Train train = service.getTrainByTrainNo(trainNo);
            model.addAttribute("train", train);
            page="editTrainPage";
        } catch (TrainNotFoundException e) {
            e.printStackTrace();
            attributes.addAttribute("message", e.getMessage());
            page="redirect:getAllTrains";
        }
        return page;
    }

    @PostMapping("/update")
    public String updateTrain(
            @ModelAttribute Train train,
            RedirectAttributes attributes
    ) {
        service.updateTrain(train);
        int trainNo= train.getTrainNo();
        attributes.addAttribute("message", "Train with train Number: '"+trainNo+"' is updated successfully !");
        return "redirect:getAllTrains";
    }
    @GetMapping("/delete")
    public String deleteTrain(
            @RequestParam int trainNo,
            RedirectAttributes attributes
    ) {
        try {
            service.deleteTrainByTrainNo(trainNo);
            attributes.addAttribute("message", "Train with trainNo : '"+trainNo+"' is removed successfully!");
        } catch (TrainNotFoundException e) {
            e.printStackTrace();
            attributes.addAttribute("message", e.getMessage());
        }
        return "redirect:getAllTrains";
    }


}
