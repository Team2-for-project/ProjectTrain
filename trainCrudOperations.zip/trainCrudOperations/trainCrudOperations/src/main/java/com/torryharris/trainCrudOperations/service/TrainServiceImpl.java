package com.torryharris.trainCrudOperations.service;

import com.torryharris.trainCrudOperations.exception.TrainNotFoundException;
import com.torryharris.trainCrudOperations.model.Train;
import com.torryharris.trainCrudOperations.repository.TrainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TrainServiceImpl implements TrainService{
    @Autowired
    private TrainRepository repo;
    @Override
    public Train saveTrain(Train train) {
        return repo.save(train);
    }

    @Override
    public List<Train> getAllTrains() {
        return repo.findAll();
    }

    @Override
    public Train getTrainByTrainNo(int trainNO) {
        Optional<Train> opt = repo.findById(trainNO);
        if(opt.isPresent()) {
            return opt.get();
        } else {
            throw new TrainNotFoundException("Train with Number: "+trainNO+" Not Found");
        }
    }

    @Override
    public void deleteTrainByTrainNo(int trainNO) {
     repo.delete(getTrainByTrainNo(trainNO));
    }

    @Override
    public void updateTrain(Train train) {
      repo.save(train);
    }
}
