package com.torryharris.trainCrudOperations.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.Id;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Train {

    @Id
    @GeneratedValue
    private int trainNo;
    private String trainName;
    private String source;
    private String destination;
    private double ticketPrice;

}
