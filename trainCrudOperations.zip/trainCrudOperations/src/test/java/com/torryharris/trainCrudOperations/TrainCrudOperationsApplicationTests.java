package com.torryharris.trainCrudOperations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainCrudOperationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
